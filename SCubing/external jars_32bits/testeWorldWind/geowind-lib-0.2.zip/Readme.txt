For further information about installation, setup, and library use see:
   http://geowind.javaforge.com
